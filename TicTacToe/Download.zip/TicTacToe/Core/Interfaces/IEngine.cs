﻿namespace TicTacToe.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
