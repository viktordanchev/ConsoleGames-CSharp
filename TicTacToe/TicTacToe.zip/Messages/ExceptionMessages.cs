﻿namespace TicTacToe.Messages
{
    public class ExceptionMessages
    {
        public const string InvalidNumber = "Invalid input! Please enter valid position.";
        public const string AlreadyFilled = "Тhis position is already filled.";
    }
}
